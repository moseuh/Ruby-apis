class Userdetail < ApplicationRecord
end
