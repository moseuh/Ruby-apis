class HighScore < ApplicationRecord
end
