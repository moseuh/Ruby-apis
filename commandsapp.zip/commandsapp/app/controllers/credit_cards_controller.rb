class CreditCardsController < ApplicationController
  def open
  end

  def debit
  end

  def credit
  end

  def close
  end
end
