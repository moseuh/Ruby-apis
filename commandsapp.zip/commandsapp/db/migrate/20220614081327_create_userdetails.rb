class CreateUserdetails < ActiveRecord::Migration[7.0]
  def change
    create_table :userdetails do |t|

      t.timestamps
    end
  end
end
