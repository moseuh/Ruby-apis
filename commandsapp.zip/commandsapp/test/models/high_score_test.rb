require "test_helper"

class HighScoreTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
