require "test_helper"

class UserdetailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
