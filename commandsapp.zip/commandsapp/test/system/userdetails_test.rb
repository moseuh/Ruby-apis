require "application_system_test_case"

class UserdetailsTest < ApplicationSystemTestCase
  setup do
    @userdetail = userdetails(:one)
  end

  test "visiting the index" do
    visit userdetails_url
    assert_selector "h1", text: "Userdetails"
  end

  test "should create userdetail" do
    visit userdetails_url
    click_on "New userdetail"

    click_on "Create Userdetail"

    assert_text "Userdetail was successfully created"
    click_on "Back"
  end

  test "should update Userdetail" do
    visit userdetail_url(@userdetail)
    click_on "Edit this userdetail", match: :first

    click_on "Update Userdetail"

    assert_text "Userdetail was successfully updated"
    click_on "Back"
  end

  test "should destroy Userdetail" do
    visit userdetail_url(@userdetail)
    click_on "Destroy this userdetail", match: :first

    assert_text "Userdetail was successfully destroyed"
  end
end
